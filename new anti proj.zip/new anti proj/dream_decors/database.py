"""
database.py - SQLite Database Initialization and Helpers
Dream Decors - Phase 2: Decoration Catalog + Smart Booking
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'dream_decors.db')


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db_connection()
    cur  = conn.cursor()

    # ── Admin Users ────────────────────────────────────────
    cur.execute('''
        CREATE TABLE IF NOT EXISTS admin_users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT    NOT NULL UNIQUE,
            password TEXT    NOT NULL
        )
    ''')
    cur.execute("SELECT COUNT(*) FROM admin_users WHERE username='admin'")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO admin_users (username,password) VALUES ('admin','admin123')")

    # ── Decorations Catalog ────────────────────────────────
    cur.execute('''
        CREATE TABLE IF NOT EXISTS decorations (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type       TEXT    NOT NULL,
            decoration_name  TEXT    NOT NULL,
            package_name     TEXT    NOT NULL,
            price            INTEGER NOT NULL,
            image_path       TEXT    DEFAULT '',
            gradient_class   TEXT    DEFAULT 'grad-gold',
            icon             TEXT    DEFAULT '✨',
            description      TEXT    NOT NULL,
            highlights       TEXT    NOT NULL,
            is_popular       INTEGER DEFAULT 0,
            is_active        INTEGER DEFAULT 1,
            created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # ── Bookings ───────────────────────────────────────────
    cur.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT    NOT NULL,
            phone         TEXT    NOT NULL,
            email         TEXT    NOT NULL,
            event_type    TEXT    NOT NULL,
            event_date    TEXT    NOT NULL,
            message       TEXT,
            decoration_id INTEGER REFERENCES decorations(id),
            package_name  TEXT    DEFAULT '',
            quoted_price  INTEGER DEFAULT 0,
            booking_ref   TEXT    DEFAULT '',
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Safe migration: add new columns to existing bookings table
    _safe_add_column(cur, 'bookings', 'decoration_id', 'INTEGER')
    _safe_add_column(cur, 'bookings', 'package_name',  'TEXT DEFAULT ""')
    _safe_add_column(cur, 'bookings', 'quoted_price',  'INTEGER DEFAULT 0')
    _safe_add_column(cur, 'bookings', 'booking_ref',   'TEXT DEFAULT ""')

    # ── Feedback ───────────────────────────────────────────
    cur.execute('''
        CREATE TABLE IF NOT EXISTS feedback (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT    NOT NULL,
            email      TEXT    NOT NULL,
            rating     INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
            message    TEXT    NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # ── Seed decorations if empty ──────────────────────────
    cur.execute("SELECT COUNT(*) FROM decorations")
    if cur.fetchone()[0] == 0:
        _seed_decorations(cur)

    conn.commit()
    conn.close()
    print("[DB] Database initialised successfully.")


def _safe_add_column(cur, table, column, col_type):
    """Add a column to an existing table if it doesn't exist."""
    try:
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")
    except sqlite3.OperationalError:
        pass  # column already exists


# ──────────────────────────────────────────────────────────
#  SEED DATA  –  12 decorations per 7 categories = 84 total
# ──────────────────────────────────────────────────────────
def _seed_decorations(cur):
    decorations = [

        # ───── WEDDING (12) ────────────────────────────────
        ("Wedding","Royal Ivory Ballroom","Silver",25000,"","grad-rose","💍",
         "An elegant ivory-and-gold ballroom setup for your perfect wedding.",
         "Floral arch,Ivory draping,Table centerpieces,Welcome sign",1),
        ("Wedding","Golden Floral Arch","Gold",45000,"","grad-gold","🌸",
         "Stunning floor-to-ceiling floral arch with premium fresh flowers.",
         "Floral arch,Fairy lights,Aisle décor,Throne chairs",1),
        ("Wedding","Moonlit Garden","Diamond",85000,"","grad-night","🌙",
         "A dreamy moonlit garden aesthetic with starry backdrops and lush florals.",
         "Star backdrop,Fog effect,Floral ceiling,Candle clusters",1),
        ("Wedding","Pearl Cascade","Silver",28000,"","grad-pearl","🤍",
         "Soft white-and-pearl theme with cascading floral drops.",
         "Pearl garlands,White roses,Draped fabric,Pillar décor",0),
        ("Wedding","Enchanted Forest","Gold",52000,"","grad-forest","🌿",
         "Whimsical forest theme with moss walls, ferns and fairy lights.",
         "Moss wall,Fairy lights,Rustic arches,Floral clusters",1),
        ("Wedding","Midnight Rose","Diamond",95000,"","grad-darkrose","🥀",
         "Dramatic dark-floral luxury with deep red roses and gold candelabras.",
         "Red roses,Gold candelabras,Black draping,Crystal chandeliers",0),
        ("Wedding","Crystal Canopy","Gold",60000,"","grad-crystal","💎",
         "A breathtaking crystal-and-white canopy spanning the entire mandap.",
         "Crystal canopy,White lilies,LED ceiling,Grand entrance gate",1),
        ("Wedding","Blush & Gold Glow","Silver",32000,"","grad-blush","🌺",
         "Soft blush florals paired with gold-frame arches and warm lighting.",
         "Blush flowers,Gold frames,String lights,Petal aisle",0),
        ("Wedding","Celestial Dreams","Diamond",110000,"","grad-celestial","⭐",
         "Sky-high luxury with a celestial theme, star clusters and fog effects.",
         "Celestial backdrop,Fog machine,Crystal tree,Floating candles",1),
        ("Wedding","Tropical Paradise","Gold",48000,"","grad-tropical","🌴",
         "Lush tropical foliage with bird-of-paradise flowers and bamboo arches.",
         "Tropical flowers,Bamboo arch,Leaf garlands,Tiki lights",0),
        ("Wedding","Vintage Romance","Silver",22000,"","grad-vintage","🕯️",
         "A timeless vintage look with antique frames, lace drapes and candlelight.",
         "Lace drapes,Antique frames,Candelabras,Dried florals",0),
        ("Wedding","Grand Royale Ballroom","Diamond",125000,"","grad-royale","👑",
         "The ultimate luxury setup — fit for royalty with opulent gold everything.",
         "Gold chandeliers,Royal throne,Full floral wall,Custom monogram",1),

        # ───── BIRTHDAY (12) ───────────────────────────────
        ("Birthday","Balloon Carnival","Silver",8000,"","grad-carnival","🎈",
         "Fun and vibrant balloon carnival with arches, columns and confetti.",
         "Balloon arch,Balloon columns,Confetti,Birthday banner",1),
        ("Birthday","Galaxy Night Party","Gold",18000,"","grad-galaxy","🌌",
         "A stunning galaxy-themed setup with neon stars and dark-glow décor.",
         "Neon stars,Dark draping,LED planets,Count-down clock",1),
        ("Birthday","Princess Paradise","Silver",12000,"","grad-princess","👸",
         "A magical princess-themed party with pink castle backdrop and tiaras.",
         "Castle backdrop,Pink balloons,Crown props,Glitter floor",1),
        ("Birthday","Superhero Bash","Silver",10000,"","grad-superhero","🦸",
         "Action-packed superhero party with themed props and comic-style décor.",
         "Hero backdrop,Action props,Themed balloons,Confetti cannon",0),
        ("Birthday","Disco Fever","Gold",22000,"","grad-disco","🪩",
         "Retro disco party with mirror balls, neon lights and groovy décor.",
         "Mirror ball,Neon strips,Disco backdrop,Glitter props",0),
        ("Birthday","Unicorn Dreams","Silver",14000,"","grad-unicorn","🦄",
         "Enchanting unicorn party in pastel rainbow tones with dreamy balloons.",
         "Rainbow balloons,Unicorn props,Pastel theme,Glitter curtain",1),
        ("Birthday","Under the Sea","Gold",20000,"","grad-ocean","🐚",
         "Dive into an underwater world with ocean-blue décor and sea creatures.",
         "Ocean backdrop,Bubble props,Jellyfish lamps,Coral centerpiece",0),
        ("Birthday","Safari Adventure","Silver",11000,"","grad-safari","🦁",
         "Wild safari theme with jungle greens, animal prints and explorer props.",
         "Jungle backdrop,Animal balloons,Explorer props,Leaf garlands",0),
        ("Birthday","Hollywood Glam","Gold",25000,"","grad-hollywood","🎬",
         "Red-carpet Hollywood party with clapboards, stars and gold glam props.",
         "Red carpet,Star backdrop,Gold props,Film reel décor",1),
        ("Birthday","Winter Wonderland","Gold",19000,"","grad-winter","❄️",
         "Magical snowy wonderland in whites and silvers with frost effects.",
         "Snow backdrop,Snowflake props,White balloons,Fairy lights",0),
        ("Birthday","Tropical Luau","Silver",13000,"","grad-luau","🌺",
         "Hawaiian luau vibes with flower leis, tiki torches and tropical colors.",
         "Flower garlands,Tiki torches,Tropical balloons,Grass skirt décor",0),
        ("Birthday","Neon Glow Party","Diamond",35000,"","grad-neon","💥",
         "Ultra-bright neon glow party — UV lights, neon signs and glow accessories.",
         "UV neon signs,Glow balloons,Neon draping,Black-light setup",1),

        # ───── ENGAGEMENT (12) ─────────────────────────────
        ("Engagement","Rose Canopy","Silver",15000,"","grad-rose","🌹",
         "Romantic rose canopy with cascading petals and ambient candlelight.",
         "Rose canopy,Petal floor,Candle clusters,Love sign",1),
        ("Engagement","Heart Floral Wall","Gold",35000,"","grad-heartwall","❤️",
         "Stunning giant heart floral wall as the centrepiece of your celebration.",
         "Heart floral wall,Fairy lights,Ring props,Couple throne",1),
        ("Engagement","Golden Gazebo","Gold",42000,"","grad-gold","🏛️",
         "An elegant gold gazebo draped with fairy lights and white flowers.",
         "Gold gazebo,White flowers,String lights,Floral aisle",0),
        ("Engagement","Vintage Garden","Silver",18000,"","grad-vintage","🌷",
         "Rustic vintage garden with wooden props, lanterns and wildflowers.",
         "Wooden arches,Lanterns,Wildflowers,Lace table runners",0),
        ("Engagement","Boho Chic","Silver",20000,"","grad-boho","🪶",
         "Bohemian-chic engagement décor with macramé, pampas grass and earthy tones.",
         "Macramé arch,Pampas grass,Earthy tones,Candle wall",1),
        ("Engagement","Starlit Romance","Gold",38000,"","grad-celestial","🌟",
         "A night-sky-inspired setup with fairy-light constellation backdrops.",
         "Star canopy,Constellation backdrop,White florals,Love seat",1),
        ("Engagement","Minimalist Luxe","Gold",40000,"","grad-pearl","🤍",
         "Clean, minimal luxury with white structures, greenery and golden accents.",
         "White arches,Greenery garlands,Gold accents,Pebble aisle",0),
        ("Engagement","Tropical Romance","Silver",16000,"","grad-tropical","🌸",
         "Tropical lushness with hibiscus, palm leaves and pastel ribbons.",
         "Tropical flowers,Palm arch,Pastel ribbons,Shell table décor",0),
        ("Engagement","Royal Proposal Stage","Diamond",65000,"","grad-royale","💍",
         "A dramatic royal stage for the big moment with velvet curtains and roses.",
         "Velvet backdrop,Rose pillars,Royal throne,Fog effect",1),
        ("Engagement","Candlelit Dream","Silver",22000,"","grad-darkrose","🕯️",
         "Hundreds of floating candles with ivory florals for a magical evening.",
         "Floating candles,Ivory flowers,Mirror aisle,Chandelier",0),
        ("Engagement","Garden Party Bloom","Silver",17000,"","grad-forest","🌻",
         "Bright garden party with sunflowers, lanterns and picnic-style seating.",
         "Sunflowers,Garden lanterns,Picnic seating,Flower crown station",0),
        ("Engagement","Midnight Luxe","Diamond",70000,"","grad-night","🌙",
         "Midnight-black-and-gold opulence for an unforgettable evening.",
         "Black & gold theme,Crystal balls,Star backdrop,Fog effect",1),

        # ───── BABY SHOWER (12) ────────────────────────────
        ("Baby Shower","Twinkle Little Star","Silver",10000,"","grad-baby","⭐",
         "Sweet star-themed baby shower in pastels with cloud balloons.",
         "Star garlands,Cloud balloons,Pastel draping,Cake table",1),
        ("Baby Shower","It's a Girl!","Silver",9000,"","grad-princess","👧",
         "Soft pink and gold baby shower celebrating a precious little girl.",
         "Pink balloons,Gold crown props,Floral table,Gift station",1),
        ("Baby Shower","It's a Boy!","Silver",9000,"","grad-babyblue","👦",
         "Cool blue-and-white nautical baby shower for a precious baby boy.",
         "Blue balloons,Anchor props,Nautical bunting,Gift corner",1),
        ("Baby Shower","Jungle Safari Baby","Gold",18000,"","grad-safari","🦒",
         "Adorable jungle safari baby shower with plush animal friends.",
         "Jungle backdrop,Animal cutouts,Leaf garlands,Crib display",1),
        ("Baby Shower","Floral Garden Baby","Silver",12000,"","grad-blush","🌸",
         "A sweet floral garden shower in blush and white for mom-to-be.",
         "Floral arch,Blush balloons,Garden seating,Petal table",0),
        ("Baby Shower","Oh Baby Cloud Nine","Gold",20000,"","grad-cloud","☁️",
         "Dreamy cloud-themed shower with floating pom-poms and sky-blue draping.",
         "Cloud pom-poms,Sky draping,Star props,Floral backdrop",0),
        ("Baby Shower","Butterfly Garden","Silver",11000,"","grad-butterfly","🦋",
         "Whimsical butterfly garden with pastel garlands and flower crowns.",
         "Butterfly props,Pastel garlands,Flower crowns,Cake table",0),
        ("Baby Shower","Sweet Little Pumpkin","Silver",10000,"","grad-orange","🎃",
         "Autumn pumpkin theme with warm oranges and terracotta tones.",
         "Pumpkin props,Autumn leaves,Warm balloons,Wreath display",0),
        ("Baby Shower","Under the Rainbow","Gold",16000,"","grad-rainbow","🌈",
         "Colourful rainbow theme celebrating new life with joyful décor.",
         "Rainbow arch,Cloud table,Bright balloons,Name banner",1),
        ("Baby Shower","Royal Baby Arrival","Diamond",30000,"","grad-royale","👑",
         "Grand royal arrival announcement with throne and red-carpet décor.",
         "Throne display,Red carpet,Royal balloons,Crown centerpiece",0),
        ("Baby Shower","Safari Adventure Baby","Gold",17000,"","grad-grass","🐘",
         "Safari animals come to life with plush set pieces and leaf canopy.",
         "Animal plush,Leaf canopy,Safari balloons,Crib corner",0),
        ("Baby Shower","Boho Baby Bloom","Silver",13000,"","grad-boho","🪷",
         "Earthy boho aesthetic with pampas, macramé and muted florals.",
         "Macramé,Pampas grass,Muted florals,Lanterns",0),

        # ───── CORPORATE (12) ──────────────────────────────
        ("Corporate","Boardroom Grand","Silver",20000,"","grad-corp","💼",
         "Professional conference-room setup with branded backdrops and clean lines.",
         "Branded backdrop,Podium,Table décor,Uplighting",1),
        ("Corporate","Gala Night Luxe","Gold",55000,"","grad-gala","🏆",
         "Glamorous corporate gala setup with gold-and-black luxury theme.",
         "Gold draping,Award stage,LED walls,Cocktail tables",1),
        ("Corporate","Product Launch Stage","Gold",60000,"","grad-launch","🚀",
         "High-impact product launch stage with dramatic reveal lighting.",
         "Stage setup,LED backdrop,Reveal draping,Branded flowers",1),
        ("Corporate","Award Ceremony Night","Diamond",90000,"","grad-award","🎖️",
         "Red-carpet award night with trophy displays and VIP seating.",
         "Red carpet,Trophy display,VIP seating,Star backdrop",1),
        ("Corporate","Annual Conference","Silver",25000,"","grad-corp","📊",
         "Clean, professional annual conference with branded signage.",
         "Branded signage,Speaker stage,Table arrangements,Uplighting",0),
        ("Corporate","Team Celebration","Silver",15000,"","grad-celeb","🎊",
         "Fun team-celebration setup with company colours and festive elements.",
         "Company colours,Balloon arch,Team photo wall,Buffet décor",0),
        ("Corporate","Networking Mixer","Silver",18000,"","grad-night","🤝",
         "Elegant networking event with cocktail-table décor and mood lighting.",
         "Cocktail tables,Mood lighting,Floral accents,Bar setup",0),
        ("Corporate","CEO Dinner","Gold",45000,"","grad-royale","🍽️",
         "Intimate VIP dinner for executives with fine-dining table art.",
         "Fine linen,Gold cutlery,Floral centrepiece,Candles",0),
        ("Corporate","Tech Summit Setup","Gold",50000,"","grad-tech","💻",
         "Modern sleek tech-summit stage with screens, blue lighting and brand walls.",
         "LED screens,Brand walls,Sleek podium,Blue uplights",0),
        ("Corporate","Expo Booth Décor","Silver",22000,"","grad-expo","🏢",
         "Eye-catching expo booth with branded banners, lighting and display stands.",
         "Branded banners,Display stands,Spotlights,Product shelves",0),
        ("Corporate","Fashion Show Stage","Diamond",80000,"","grad-fashion","👗",
         "Runway-ready fashion-show stage with catwalk, lighting and VIP lounges.",
         "Catwalk,Spot lighting,VIP lounge,Photo backdrop",0),
        ("Corporate","Office Launch Party","Silver",20000,"","grad-celeb","🎉",
         "Celebrate a new office opening with balloons, branding and festive touches.",
         "Balloon arch,Brand signage,Welcome banner,Ribbon ceremony",0),

        # ───── ANNIVERSARY (12) ────────────────────────────
        ("Anniversary","Silver Jubilee","Silver",20000,"","grad-silver","🥂",
         "Celebrate 25 years of love with a silver-and-white classy setup.",
         "Silver balloons,White flowers,25 sign,Candle table",1),
        ("Anniversary","Golden Jubilee","Gold",48000,"","grad-gold","🥇",
         "Magnificent golden anniversary setup with 50 roses and gold draping.",
         "50 roses,Gold draping,Milestone banner,Couple throne",1),
        ("Anniversary","Romantic Garden","Silver",18000,"","grad-rose","🌹",
         "Romantic garden anniversary with roses, fairy lights and love quotes.",
         "Roses,Fairy lights,Love quotes,Candle arch",0),
        ("Anniversary","Midnight Glow","Gold",38000,"","grad-night","🌙",
         "Moody midnight-glow anniversary with floating candles and star curtains.",
         "Star curtains,Floating candles,String lights,Monogram",1),
        ("Anniversary","Rustic Love Story","Silver",16000,"","grad-vintage","🪵",
         "Rustic wooden frames, lanterns and wildflowers for a countryside feel.",
         "Wooden frames,Lanterns,Wildflowers,Rope lights",0),
        ("Anniversary","Diamond Elegance","Diamond",75000,"","grad-crystal","💎",
         "Crystal-clear luxury with diamond-cut props and an all-white theme.",
         "Crystal props,Diamond backdrop,White florals,Uplighting",1),
        ("Anniversary","Love Terrace","Silver",22000,"","grad-tropical","🌅",
         "Outdoor terrace anniversary decorated for a breezy, intimate sunset.",
         "Terrace strings,Potted flowers,Love sign,Lanterns",0),
        ("Anniversary","Parisian Romance","Gold",42000,"","grad-paris","🗼",
         "French-inspired chic anniversary with Eiffel prop and lavender palette.",
         "Eiffel prop,Lavender flowers,French bunting,Bistro tables",0),
        ("Anniversary","Tropical Escape","Silver",17000,"","grad-luau","🌺",
         "Island anniversary with tropical blooms, bamboo and warm candle glow.",
         "Bamboo arch,Tropical florals,Tiki candles,Hanging lamps",0),
        ("Anniversary","Royal Couple Dais","Diamond",85000,"","grad-royale","👑",
         "Grand royal dais for the couple of honour with velvet and gold opulence.",
         "Royal dais,Velvet draping,Gold props,Floral wall",1),
        ("Anniversary","Whimsical Lights","Silver",14000,"","grad-fairy","✨",
         "Magical fairy-tale lighting setup with thousands of fairy lights.",
         "Fairy lights,Draping,Floral clusters,Photo corner",0),
        ("Anniversary","Memory Lane Wall","Gold",30000,"","grad-blush","📸",
         "A stunning photo memory wall displaying your years together in golden frames.",
         "Photo wall,Golden frames,Timeline décor,Flower arch",1),

        # ───── GRADUATION (12) ─────────────────────────────
        ("Graduation","Classic Grad Party","Silver",8000,"","grad-corp","🎓",
         "Celebrate academic achievement with cap-and-gown themed décor.",
         "Graduation caps,Academic colors,Scroll props,Photo wall",1),
        ("Graduation","Gold Scholar","Gold",18000,"","grad-gold","📜",
         "Premium gold-and-black graduation party with elegant achievement display.",
         "Gold balloons,Achievement wall,Class banner,Trophy display",1),
        ("Graduation","Future is Bright","Silver",10000,"","grad-neon","☀️",
         "Bright, colourful grad celebration with motivational quotes and neons.",
         "Neon quotes,Colourful balloons,Yearbook display,Selfie wall",0),
        ("Graduation","Grand Achievement","Diamond",35000,"","grad-royale","🏅",
         "A grand graduation party with keynote stage, hall décor and photo rooms.",
         "Stage setup,Photo rooms,Grand backdrop,Hall decorations",1),
        ("Graduation","STEM Celebration","Silver",12000,"","grad-tech","🔬",
         "Science-and-tech themed grad party with circuit-board and neon accents.",
         "Circuit props,Neon accents,Lab-inspired décor,Achievement board",0),
        ("Graduation","Law & Order","Silver",11000,"","grad-corp","⚖️",
         "Navy-and-gold legal graduation themed décor with gavel and scroll props.",
         "Navy balloons,Gavel props,Scroll décor,Achievement wall",0),
        ("Graduation","Med School Milestone","Silver",11000,"","grad-forest","🩺",
         "Medical graduation celebration with stethoscope props and clean whites.",
         "Medical props,White & blue theme,Achievement board,Photo wall",0),
        ("Graduation","Arts & Design Bash","Gold",20000,"","grad-carnival","🎨",
         "Creative explosion of colours for arts and design graduates.",
         "Paint-splash props,ColourBurst backdrop,Frame wall,Easel display",0),
        ("Graduation","Business Mogul","Gold",22000,"","grad-gala","💹",
         "Sleek business-school graduation with briefcase props and marble look.",
         "Marble backdrop,Briefcase props,Gold accents,Champagne table",1),
        ("Graduation","Class of Champions","Silver",9000,"","grad-celeb","🏆",
         "Sports-inspired graduation bash with championship trophies and team colors.",
         "Trophy props,Team colors,Banner wall,Confetti cannon",0),
        ("Graduation","Luxury Farewell","Diamond",40000,"","grad-crystal","💫",
         "The ultimate luxury graduation farewell event with diamond and crystal.",
         "Crystal table,Diamond props,Gold draping,Photo suite",0),
        ("Graduation","Garden of Scholars","Gold",16000,"","grad-forest","🌿",
         "Fresh garden graduate party with botanical props and earthy tones.",
         "Botanical props,Greenery arch,Earthy tones,Book display",0),
    ]

    cur.executemany('''
        INSERT INTO decorations
            (event_type, decoration_name, package_name, price, image_path,
             gradient_class, icon, description, highlights, is_popular)
        VALUES (?,?,?,?,?,?,?,?,?,?)
    ''', decorations)


if __name__ == '__main__':
    import os
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print("[DB] Old database removed for fresh seed.")
    init_db()
    print("[DB] Done!")
