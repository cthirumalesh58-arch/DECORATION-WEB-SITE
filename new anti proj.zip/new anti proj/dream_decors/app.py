"""
app.py - Main Flask Application (Phase 2: Decoration Catalog + Smart Booking)
Dream Decors - Event Decoration Company
Run: python app.py
"""

import os
import uuid
import json
from flask import (
    Flask, render_template, request,
    redirect, url_for, flash, session,
    jsonify, send_from_directory
)
from werkzeug.utils import secure_filename
from database import init_db, get_db_connection

app = Flask(__name__)
app.secret_key = 'dreamdecors_secret_key_2024'

# ── Upload Config ──────────────────────────────────────────
UPLOAD_FOLDER   = os.path.join(os.path.dirname(__file__), 'static', 'images', 'uploads')
ALLOWED_EXT     = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER']    = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024  # 8 MB

init_db()

# ──────────────────────────────────────────────────────────
#  HELPERS
# ──────────────────────────────────────────────────────────
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

def generate_booking_ref():
    """Generate a unique booking reference like DD-2024-0001."""
    conn = get_db_connection()
    count = conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
    conn.close()
    return f"DD-2026-{count + 1:04d}"

CATEGORIES = ['Wedding', 'Birthday', 'Engagement', 'Baby Shower',
              'Corporate', 'Anniversary', 'Graduation']

# ──────────────────────────────────────────────────────────
#  PUBLIC PAGES
# ──────────────────────────────────────────────────────────

@app.route('/')
def index():
    conn = get_db_connection()
    testimonials = conn.execute(
        'SELECT * FROM feedback ORDER BY created_at DESC LIMIT 3'
    ).fetchall()
    popular_decors = conn.execute(
        'SELECT * FROM decorations WHERE is_popular=1 AND is_active=1 ORDER BY RANDOM() LIMIT 6'
    ).fetchall()
    conn.close()
    return render_template('index.html', testimonials=testimonials, popular_decors=popular_decors)


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/services')
def services():
    conn = get_db_connection()
    # Get one popular decoration per category for preview
    previews = {}
    for cat in CATEGORIES:
        row = conn.execute(
            "SELECT * FROM decorations WHERE event_type=? AND is_active=1 AND is_popular=1 LIMIT 1",
            (cat,)
        ).fetchone()
        previews[cat] = row
    conn.close()
    return render_template('services.html', previews=previews, categories=CATEGORIES)


@app.route('/gallery')
def gallery():
    conn = get_db_connection()
    decorations = conn.execute(
        "SELECT * FROM decorations WHERE is_active=1 ORDER BY is_popular DESC, RANDOM() LIMIT 24"
    ).fetchall()
    conn.close()
    return render_template('gallery.html', decorations=decorations, categories=CATEGORIES)


@app.route('/contact')
def contact():
    return render_template('contact.html')


# ──────────────────────────────────────────────────────────
#  DECORATION CATALOG
# ──────────────────────────────────────────────────────────

@app.route('/catalog')
def catalog():
    category = request.args.get('category', 'All')
    query    = request.args.get('q', '').strip()
    conn     = get_db_connection()

    sql  = "SELECT * FROM decorations WHERE is_active=1"
    args = []

    if category and category != 'All':
        sql  += " AND event_type=?"
        args.append(category)

    if query:
        sql  += " AND (decoration_name LIKE ? OR description LIKE ? OR package_name LIKE ?)"
        args += [f'%{query}%', f'%{query}%', f'%{query}%']

    sql += " ORDER BY is_popular DESC, price ASC"
    decorations = conn.execute(sql, args).fetchall()
    conn.close()
    return render_template('catalog.html',
                           decorations=decorations,
                           categories=CATEGORIES,
                           current_cat=category,
                           current_q=query)


@app.route('/decoration/<int:decoration_id>')
def decoration_detail(decoration_id):
    """Return decoration details as JSON for the popup lightbox."""
    conn = get_db_connection()
    dec  = conn.execute(
        "SELECT * FROM decorations WHERE id=? AND is_active=1", (decoration_id,)
    ).fetchone()
    conn.close()
    if not dec:
        return jsonify({'error': 'Not found'}), 404
    return jsonify({
        'id':              dec['id'],
        'event_type':      dec['event_type'],
        'decoration_name': dec['decoration_name'],
        'package_name':    dec['package_name'],
        'price':           dec['price'],
        'image_path':      dec['image_path'],
        'gradient_class':  dec['gradient_class'],
        'icon':            dec['icon'],
        'description':     dec['description'],
        'highlights':      dec['highlights'],
        'is_popular':      dec['is_popular'],
    })


# ──────────────────────────────────────────────────────────
#  BOOKING
# ──────────────────────────────────────────────────────────

@app.route('/booking', methods=['GET', 'POST'])
def booking():
    # Pre-fill context from URL params (smart booking flow)
    prefill = {
        'decoration_id':    request.args.get('decoration_id', ''),
        'decoration_name':  request.args.get('decoration_name', ''),
        'event_type':       request.args.get('event_type', ''),
        'package_name':     request.args.get('package', ''),
        'quoted_price':     request.args.get('price', ''),
    }

    # Load decoration object if id given
    selected_decoration = None
    if prefill['decoration_id']:
        conn = get_db_connection()
        selected_decoration = conn.execute(
            "SELECT * FROM decorations WHERE id=?", (prefill['decoration_id'],)
        ).fetchone()
        conn.close()

    if request.method == 'POST':
        name          = request.form.get('name', '').strip()
        phone         = request.form.get('phone', '').strip()
        email         = request.form.get('email', '').strip()
        event_type    = request.form.get('event_type', '').strip()
        event_date    = request.form.get('event_date', '').strip()
        message       = request.form.get('message', '').strip()
        decoration_id = request.form.get('decoration_id', '') or None
        package_name  = request.form.get('package_name', '').strip()
        quoted_price  = request.form.get('quoted_price', '0').strip() or '0'

        if not all([name, phone, email, event_type, event_date]):
            flash('Please fill in all required fields.', 'error')
            return redirect(url_for('booking', **request.form))

        booking_ref = generate_booking_ref()

        conn = get_db_connection()
        conn.execute('''
            INSERT INTO bookings
                (name, phone, email, event_type, event_date, message,
                 decoration_id, package_name, quoted_price, booking_ref)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        ''', (name, phone, email, event_type, event_date, message,
              decoration_id, package_name, int(quoted_price), booking_ref))
        conn.commit()
        conn.close()

        flash(f'Booking confirmed! Your Booking ID: <strong>{booking_ref}</strong>. We\'ll contact you soon.', 'success')
        return redirect(url_for('booking'))

    return render_template('booking.html',
                           prefill=prefill,
                           selected_decoration=selected_decoration,
                           categories=CATEGORIES)


# ──────────────────────────────────────────────────────────
#  FEEDBACK
# ──────────────────────────────────────────────────────────

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        name    = request.form.get('name', '').strip()
        email   = request.form.get('email', '').strip()
        rating  = request.form.get('rating', '5').strip()
        message = request.form.get('message', '').strip()

        if not all([name, email, rating, message]):
            flash('Please fill in all fields.', 'error')
            return redirect(url_for('feedback'))
        try:
            rating_int = int(rating)
            assert 1 <= rating_int <= 5
        except Exception:
            flash('Invalid rating.', 'error')
            return redirect(url_for('feedback'))

        conn = get_db_connection()
        conn.execute(
            'INSERT INTO feedback (name,email,rating,message) VALUES (?,?,?,?)',
            (name, email, rating_int, message)
        )
        conn.commit()
        conn.close()
        flash('Thank you for your feedback!', 'success')
        return redirect(url_for('feedback'))

    conn  = get_db_connection()
    reviews = conn.execute('SELECT * FROM feedback ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('feedback.html', reviews=reviews)


# ──────────────────────────────────────────────────────────
#  ADMIN — AUTH
# ──────────────────────────────────────────────────────────

@app.route('/admin')
def admin():
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_dashboard'))
    return render_template('admin/login.html')


@app.route('/admin/login', methods=['POST'])
def admin_login():
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()
    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM admin_users WHERE username=? AND password=?',
        (username, password)
    ).fetchone()
    conn.close()
    if user:
        session['admin_logged_in'] = True
        session['admin_username']  = username
        return redirect(url_for('admin_dashboard'))
    flash('Invalid credentials.', 'error')
    return redirect(url_for('admin'))


@app.route('/admin/logout')
def admin_logout():
    session.clear()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('admin'))


# ──────────────────────────────────────────────────────────
#  ADMIN — DASHBOARD
# ──────────────────────────────────────────────────────────

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin_logged_in'):
        flash('Please log in.', 'error')
        return redirect(url_for('admin'))

    conn = get_db_connection()
    bookings     = conn.execute('SELECT b.*, d.decoration_name FROM bookings b LEFT JOIN decorations d ON b.decoration_id=d.id ORDER BY b.created_at DESC').fetchall()
    reviews      = conn.execute('SELECT * FROM feedback ORDER BY created_at DESC').fetchall()
    decorations  = conn.execute('SELECT * FROM decorations ORDER BY event_type, price').fetchall()
    top_decors   = conn.execute('''
        SELECT d.decoration_name, d.event_type, d.package_name, COUNT(b.id) as booking_count
        FROM decorations d
        LEFT JOIN bookings b ON b.decoration_id = d.id
        WHERE d.is_active=1
        GROUP BY d.id
        ORDER BY booking_count DESC
        LIMIT 10
    ''').fetchall()
    conn.close()

    return render_template('admin/dashboard.html',
                           bookings=bookings,
                           reviews=reviews,
                           decorations=decorations,
                           top_decors=top_decors,
                           categories=CATEGORIES)


# ──────────────────────────────────────────────────────────
#  ADMIN — DECORATION CRUD
# ──────────────────────────────────────────────────────────

@app.route('/admin/decorations/add', methods=['POST'])
def admin_decoration_add():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin'))

    # Handle image upload
    image_path = ''
    if 'image' in request.files:
        f = request.files['image']
        if f and f.filename and allowed_file(f.filename):
            filename   = secure_filename(f.filename)
            unique_fn  = f"{uuid.uuid4().hex}_{filename}"
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], unique_fn))
            image_path = f"images/uploads/{unique_fn}"

    conn = get_db_connection()
    conn.execute('''
        INSERT INTO decorations
            (event_type, decoration_name, package_name, price,
             image_path, gradient_class, icon, description, highlights, is_popular)
        VALUES (?,?,?,?,?,?,?,?,?,?)
    ''', (
        request.form.get('event_type'),
        request.form.get('decoration_name'),
        request.form.get('package_name'),
        int(request.form.get('price', 0)),
        image_path,
        request.form.get('gradient_class', 'grad-gold'),
        request.form.get('icon', '✨'),
        request.form.get('description', ''),
        request.form.get('highlights', ''),
        1 if request.form.get('is_popular') else 0,
    ))
    conn.commit()
    conn.close()
    flash('Decoration added successfully!', 'success')
    return redirect(url_for('admin_dashboard') + '#tab-decorations')


@app.route('/admin/decorations/edit/<int:dec_id>', methods=['POST'])
def admin_decoration_edit(dec_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin'))

    image_path = request.form.get('existing_image', '')
    if 'image' in request.files:
        f = request.files['image']
        if f and f.filename and allowed_file(f.filename):
            filename  = secure_filename(f.filename)
            unique_fn = f"{uuid.uuid4().hex}_{filename}"
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], unique_fn))
            image_path = f"images/uploads/{unique_fn}"

    conn = get_db_connection()
    conn.execute('''
        UPDATE decorations
        SET event_type=?, decoration_name=?, package_name=?, price=?,
            image_path=?, gradient_class=?, icon=?, description=?,
            highlights=?, is_popular=?
        WHERE id=?
    ''', (
        request.form.get('event_type'),
        request.form.get('decoration_name'),
        request.form.get('package_name'),
        int(request.form.get('price', 0)),
        image_path,
        request.form.get('gradient_class', 'grad-gold'),
        request.form.get('icon', '✨'),
        request.form.get('description', ''),
        request.form.get('highlights', ''),
        1 if request.form.get('is_popular') else 0,
        dec_id,
    ))
    conn.commit()
    conn.close()
    flash('Decoration updated!', 'success')
    return redirect(url_for('admin_dashboard') + '#tab-decorations')


@app.route('/admin/decorations/delete/<int:dec_id>', methods=['POST'])
def admin_decoration_delete(dec_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin'))
    conn = get_db_connection()
    conn.execute("UPDATE decorations SET is_active=0 WHERE id=?", (dec_id,))
    conn.commit()
    conn.close()
    flash('Decoration removed from catalog.', 'success')
    return redirect(url_for('admin_dashboard') + '#tab-decorations')


if __name__ == '__main__':
    app.run(debug=True, port=5000)
